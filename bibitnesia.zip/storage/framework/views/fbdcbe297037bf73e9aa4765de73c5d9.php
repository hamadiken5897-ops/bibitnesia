

<div class="tab-postingan-container">
    
    <div class="empty-state">
        <i class="bi bi-chat-square-text"></i>
        <h5>Fitur Postingan</h5>
        <p class="text-muted">Fitur ini sedang dalam tahap pengembangan.</p>
        <div class="alert alert-info d-inline-block mt-3" role="alert">
            <i class="bi bi-info-circle me-2"></i>
            <strong>Coming Soon!</strong> Anda akan dapat berbagi postingan, tips berkebun, dan update lainnya.
        </div>
    </div>

</div>

<?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/profile/components/tab-postingan.blade.php ENDPATH**/ ?>