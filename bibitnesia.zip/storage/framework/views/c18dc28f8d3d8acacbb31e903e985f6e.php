<div class="sidebar">
    <div class="sidebar-logo">
        <i class="fas fa-seedling"></i>
        <span>Bibitnesia</span>
    </div>

    <ul class="sidebar-menu">
        <li class="<?php echo e(request()->is('marketplace') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('marketplace.index')); ?>">
                <i class="fas fa-home"></i> Beranda
            </a>
        </li>

        <li class="<?php echo e(request()->is('keranjang') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('keranjang.index')); ?>">
                <i class="fas fa-shopping-cart"></i> Keranjang
            </a>
        </li>

        <li class="<?php echo e(request()->is('favorit') ? 'active' : ''); ?>">
            <a href="#">
                <i class="fas fa-heart"></i> Favorit
            </a>
        </li>

        <li class="<?php echo e(request()->is('pesanan') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('pesanan.index')); ?>">
                <i class="fas fa-box"></i> Pesanan Saya
            </a>
        </li>

        <li>
            <a href="#">
                <i class="fas fa-history"></i> Riwayat
            </a>
        </li>

        <li>
            <a href="#">
                <i class="fas fa-store"></i> Jadi Penjual
            </a>
        </li>

        <li>
            <a href="#">
                <i class="fas fa-cog"></i> Pengaturan
            </a>
        </li>

        <li>
            <a href="#">
                <i class="fas fa-question-circle"></i> Bantuan
            </a>
        </li>
    </ul>
</div>
<?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/layouts/marketplace/partials/sidebar.blade.php ENDPATH**/ ?>