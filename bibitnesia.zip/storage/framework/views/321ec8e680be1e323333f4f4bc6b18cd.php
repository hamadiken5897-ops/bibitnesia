<script src="<?php echo e(asset('dist/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('dist/assets/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('dist/assets/vendors/apexcharts/apexcharts.js')); ?>"></script>
<script src="<?php echo e(asset('dist/assets/js/pages/dashboard.js')); ?>"></script>

<script src="<?php echo e(asset('dist/assets/js/main.js')); ?>"></script>

<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/layouts/admin/partials/scripts.blade.php ENDPATH**/ ?>