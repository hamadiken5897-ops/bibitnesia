<?php if($produk->hasPages()): ?>
    <div class="pagination-wrapper d-flex justify-content-center mt-4">

        
        <?php if($produk->onFirstPage()): ?>
            <span class="btn btn-light mx-1 disabled">
                <i class="fas fa-chevron-left"></i>
            </span>
        <?php else: ?>
            <a href="<?php echo e($produk->previousPageUrl()); ?>" class="btn btn-light mx-1">
                <i class="fas fa-chevron-left"></i>
            </a>
        <?php endif; ?>


        
        <?php $__currentLoopData = $produk->links()->elements[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $produk->currentPage()): ?>
                <span class="btn btn-success mx-1 text-white"><?php echo e($page); ?></span>
            <?php else: ?>
                <a href="<?php echo e($url); ?>" class="btn btn-light mx-1"><?php echo e($page); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        
        <?php if($produk->hasMorePages()): ?>
            <a href="<?php echo e($produk->nextPageUrl()); ?>" class="btn btn-light mx-1">
                <i class="fas fa-chevron-right"></i>
            </a>
        <?php else: ?>
            <span class="btn btn-light mx-1 disabled">
                <i class="fas fa-chevron-right"></i>
            </span>
        <?php endif; ?>

    </div>
<?php endif; ?>
<?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/layouts/marketplace/components/pagination.blade.php ENDPATH**/ ?>