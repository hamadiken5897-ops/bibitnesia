

<div class="tab-ulasan-container">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-bold mb-0">
            <i class="bi bi-star me-2"></i>Ulasan Produk
        </h5>
    </div>

    

    <?php
        // Nanti ambil ulasan dari database
        // Contoh query (sesuaikan dengan struktur database Anda):
        // $ulasans = \App\Models\Ulasan::where('id_user', $user->id_user)->get();
        $ulasans = collect(); // Empty collection untuk sementara
    ?>

    <?php if($ulasans->count() > 0): ?>
    <div class="ulasan-list">
        <?php $__currentLoopData = $ulasans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ulasan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="ulasan-item">
            <div class="d-flex gap-3">
                
                <div class="ulasan-produk-image">
                    <img src="https://via.placeholder.com/80x80" alt="Produk">
                </div>

                
                <div class="flex-grow-1">
                    <h6 class="fw-bold mb-1">Nama Produk</h6>
                    <div class="ulasan-rating mb-2">
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star-fill text-warning"></i>
                        <i class="bi bi-star text-warning"></i>
                        <span class="ms-2 text-muted">4/5</span>
                    </div>
                    <p class="ulasan-text mb-2">
                        Produk bagus, sesuai deskripsi. Pengiriman cepat dan packing rapi.
                    </p>
                    <small class="text-muted">
                        <i class="bi bi-calendar3 me-1"></i>17 Agustus 2025
                    </small>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
    
    <div class="empty-state">
        <i class="bi bi-star"></i>
        <h5>Belum Ada Ulasan</h5>
        <?php if($isOwner ?? false): ?>
        <p class="text-muted">Anda belum memberikan ulasan pada produk apapun.</p>
        <a href="<?php echo e(route('marketplace.index')); ?>" class="btn btn-primary">
            <i class="bi bi-shop me-1"></i>Belanja Sekarang
        </a>
        <?php else: ?>
        <p class="text-muted">User ini belum memberikan ulasan.</p>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</div>

<?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/profile/components/tab-ulasan.blade.php ENDPATH**/ ?>