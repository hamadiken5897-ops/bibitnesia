<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row h-100">
        <div class="col-lg-5 col-12">
            <div id="auth-left">

                
                <div class="auth-logo">
                    <a href="/">
                        <img src="<?php echo e(asset('dist/assets/images/logo/logo bibitnesia.png')); ?>" alt="Logo"
                            style="width:250px; height:auto;">
                    </a>
                </div>

                
                <h1 class="auth-title">Log in.</h1>
                <p class="auth-subtitle mb-5">Grow with us — log in to your account.</p>

                
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php echo e($errors->first()); ?> 
                    </div>
                <?php endif; ?>

                
                <form method="POST" action="<?php echo e(route('login.post')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group position-relative has-icon-left mb-4">
                        <input type="email" name="email" class="form-control form-control-xl" placeholder="Email"
                            required>
                        <div class="form-control-icon">
                            <i class="bi bi-person"></i>
                        </div>
                    </div>

                    <div class="form-group position-relative has-icon-left mb-4">
                        <input type="password" name="password" class="form-control form-control-xl" placeholder="Password"
                            required>
                        <div class="form-control-icon">
                            <i class="bi bi-shield-lock"></i>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block btn-lg shadow-lg mt-5">
                        Log in
                    </button>
                </form>

                
                <div class="text-center mt-5 text-lg fs-4">
                    <p class="text-gray-600">
                        Don't have an account?
                        <a href="<?php echo e(route('register')); ?>" class="font-bold">Sign up</a>.
                    </p>
                    <p>
                        <a class="font-bold" href="<?php echo e(route('password.request')); ?>">Forgot password?</a>.
                    </p>
                </div>

            </div>
        </div>

        
        <div class="col-lg-7 d-none d-lg-block">
            <div id="auth-right"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/auth/login.blade.php ENDPATH**/ ?>