<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('marketplace_as/js/marketplace.js')); ?>"></script>
<?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/layouts/marketplace/partials/scripts.blade.php ENDPATH**/ ?>