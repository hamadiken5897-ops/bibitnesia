<!DOCTYPE html>
<html lang="id">

<head>
    <?php echo $__env->make('layouts.marketplace.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>

    
    <?php echo $__env->make('layouts.marketplace.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="main-content">

        
        <?php echo $__env->make('layouts.marketplace.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <?php echo $__env->yieldContent('content'); ?>

    </div>

    
    <?php echo $__env->make('layouts.marketplace.partials.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>
</html>
<?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/layouts/marketplace/main.blade.php ENDPATH**/ ?>