<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p><?php echo e(date('Y')); ?> &copy; Mazer</p>
        </div>
        <div class="float-end">
            <p>Crafted with <span class="text-danger"><i class="bi bi-heart"></i></span> by 
                <a href="http://ahmadsaugi.com">A. Saugi</a>
            </p>
        </div>
    </div>
</footer><?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/layouts/admin/partials/footer.blade.php ENDPATH**/ ?>