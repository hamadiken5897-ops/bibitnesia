<div class="header">
    <div class="header-title">
        <h1>Marketplace Bibitnesia</h1>
        <p>Temukan tanaman & bibit berkualitas dari penjual terpercaya</p>
    </div>

    <div class="header-actions">
        <?php if(auth()->guard()->check()): ?>
            <?php
                $notifs = \App\Models\NotifikasiUser::where('id_user', auth()->user()->id_user)
                    ->orderBy('created_at', 'desc')
                    ->limit(10)
                    ->get();

                // Tidak manipulasi judul → semua type & icon langsung dari database
                $notif_mapped = $notifs->map(function ($n) {
                    return [
                        'id' => $n->id_notif,
                        'judul' => $n->judul,
                        'pesan' => $n->pesan,
                        'url' => $n->redirect_url,
                        'time' => $n->created_at->diffForHumans(),
                        'type' => $n->type ?? 'normal',
                        'icon' => $n->icon ?? '🔔',
                    ];
                });
            ?>

            <script>
                window.notifs = <?php echo json_encode($notif_mapped, 15, 512) ?>;
            </script>

            <div class="nav-item ms-lg-3 position-relative">
                <a href="<?php echo e(route('notifikasi.index', ['from' => request()->path()])); ?>">
                    <i class="bi bi-bell-fill fs-4" style="color:#41A67E;"></i>
                    <?php if($notifCount > 0): ?>
                        <span class="badge bg-danger"><?php echo e($notifCount); ?></span>
                    <?php endif; ?>
                </a>
            </div>

        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <button class="profile-btn">
                <?php echo e(auth()->user()->name); ?>

            </button>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="profile-btn">
                Login
            </a>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/layouts/marketplace/partials/header.blade.php ENDPATH**/ ?>