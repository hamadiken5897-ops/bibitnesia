
<?php if(isset($produk) && $produk->count() > 0): ?>

    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product-card">

            <div class="product-image-container">

                
                <div id="carouselDB<?php echo e($index); ?>" class="carousel slide product-carousel" data-bs-ride="carousel">
                    <div class="carousel-inner">

                        
                        <?php if($item->gambar_1): ?>
                            <div class="carousel-item active">
                                <img src="<?php echo e(asset('storage/' . $item->gambar_1)); ?>" alt="<?php echo e($item->nama_produk); ?>">
                            </div>
                        <?php endif; ?>

                        
                        <?php if($item->gambar_2): ?>
                            <div class="carousel-item <?php echo e(!$item->gambar_1 ? 'active' : ''); ?>">
                                <img src="<?php echo e(asset('storage/' . $item->gambar_2)); ?>" alt="<?php echo e($item->nama_produk); ?>">
                            </div>
                        <?php endif; ?>

                        
                        <?php if($item->gambar_3): ?>
                            <div class="carousel-item <?php echo e(!$item->gambar_1 && !$item->gambar_2 ? 'active' : ''); ?>">
                                <img src="<?php echo e(asset('storage/' . $item->gambar_3)); ?>" alt="<?php echo e($item->nama_produk); ?>">
                            </div>
                        <?php endif; ?>

                        
                        <?php if(!$item->gambar_1 && !$item->gambar_2 && !$item->gambar_3): ?>
                            <div class="carousel-item active">
                                <img src="https://via.placeholder.com/400x300?text=No+Image" alt="No Image">
                            </div>
                        <?php endif; ?>

                    </div>

                    
                    <?php if($item->gambar_1 && ($item->gambar_2 || $item->gambar_3)): ?>
                        <button class="carousel-control-prev" type="button"
                            data-bs-target="#carouselDB<?php echo e($index); ?>" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                        </button>

                        <button class="carousel-control-next" type="button"
                            data-bs-target="#carouselDB<?php echo e($index); ?>" data-bs-slide="next">
                            <span class="carousel-control-next-icon"></span>
                        </button>
                    <?php endif; ?>

                </div>

                
                <?php if($item->status === 'aktif'): ?>
                    <span class="product-badge">TERSEDIA</span>
                <?php else: ?>
                    <span class="product-badge bg-danger">HABIS</span>
                <?php endif; ?>

            </div>


            <div class="product-info">
                <h3 class="product-title"><?php echo e($item->nama_produk); ?></h3>
                <div class="product-price">Rp <?php echo e(number_format($item->harga, 0, ',', '.')); ?></div>

                <div class="product-seller">
                    <i class="fas fa-store"></i> <?php echo e($item->nama_penjual); ?>

                </div>
            </div>


            <div class="product-footer">
                <div class="product-stock">
                    <i class="fas fa-box"></i> Stok: <?php echo e($item->stok); ?>

                </div>

                <div class="product-location">
                    <i class="fas fa-map-marker-alt"></i> <?php echo e($item->lokasi_penjual); ?>

                </div>
            </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>
<?php /**PATH D:\Laravel\laragon\www\bibitnesia\resources\views/layouts/marketplace/components/products_dynamic.blade.php ENDPATH**/ ?>